
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DISD3
 */
public class LoginPOE {

    private static class loginPOE extends LoginPOE {

        public loginPOE() {
        }
    }

    /**
     * @param args the command line arguments
     */public class SignupPOE {
private String firstName;
private String lastName;
private String userName;
private String password;

    public String getFirstName() {
        return firstName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class 

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public String getLastName() {
        return lastName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public String getUserName() {
        return userName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public void setUserName(String userName) {
        this.userName = userName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public String getPassword() {
        return password;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public void setPassword(String password) {
        this.password = password;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    
    
    
    
    public static void main(String[] args) {
        LoginPOE signup =new loginPOE();
        
        try(Scanner scanner =new Scanner(System.in)){
           System.out.print("Enter your Fisrt name:"); 
           String firstName= scanner.nextLine();
           signup.setFirstName(firstName);
           System.out.print("Enter your Last name:");
           String lastName= scanner.nextLine();
           signup.setLastName(lastName);
           System.out.print("Enter your Username:");
           String userName=scanner.nextLine();
           signup.setUserName(userName);
           System.out.print("Enter your Password:");
           String password=scanner.nextLine();
           signup.setPassword(password);
        
          printSignupPOEData(signup);
        }//end of try scanner
    
    
}
