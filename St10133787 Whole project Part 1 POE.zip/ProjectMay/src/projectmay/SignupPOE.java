/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectmay;
import java.util.Scanner;
import static projectmay.PasswordVal.checkPasswordValdility;
/**
 *
 * @author DISD3
 */
public class SignupPOE {
private String firstName;
private String lastName;
private String userName;
private String password;

    public String getFirstName() {
        return firstName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class 

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public String getLastName() {
        return lastName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public String getUserName() {
        return userName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public void setUserName(String userName) {
        this.userName = userName;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public String getPassword() {
        return password;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    public void setPassword(String password) {
        this.password = password;
    }//press alt and then insert to get "getters and setter" it is used to get the value of the variable outside the class

    
    
    
    
    public static void main(String[] args) {
        SignupPOE signup =new SignupPOE();
        
        try(Scanner scanner =new Scanner(System.in)){
           System.out.print("Enter your Fisrt name:"); 
           String firstName= scanner.nextLine();
           signup.setFirstName(firstName);
           System.out.print("Enter your Last name:");
           String lastName= scanner.nextLine();
           signup.setLastName(lastName);
           //supposed to prompt the username to enter username 
           String userName=scanner.nextLine();
           signup.setUserName(userName);
           //supposed to prompt the username to enter password
           String password=scanner.nextLine();
           signup.setPassword(password);
        
          printSignupPOEData(signup);
          
          
            System.out.println("Enter your Password:");
      final int numDigits=1;
      final int numuppercaseLetters=1;
      final int numlowercaseLetters=8;
      int lowerCount =0;
      int digitCount=0;
      int upperCount=0;
      int letterCount=0;
      
     Scanner in =new Scanner(System.in);
     String Password=in.nextLine();
     int inputLen=Password.length();
     for(int i=0;i<inputLen;i++){
         
     
     char ch = Password.charAt(i);
        if(Character.isUpperCase(ch))
            upperCount++;
        else if(Character.isLowerCase(ch))
         lowerCount++;
        else if (Character.isDigit(ch))
            digitCount++;
     }
        {
            if(upperCount>=numuppercaseLetters&&lowerCount>=numlowercaseLetters&&digitCount>=numDigits) 
                System.out.println("password succesfully captured");
        
        else{
                System.out.println("The password did not meet the following Criteria:");
                if(upperCount<numuppercaseLetters)
                  System.out.println("Capital letters!!!");
                if(lowerCount<numlowercaseLetters) 
                    System.out.println("not enough characters!!!");
                if (digitCount<numDigits)
                    System.out.println("not enough numbers!!");
            
            }
        }
          
         final int lowercaseLetters=5;
         int lowercase_Count=0;
      
         System.out.println("Enter your Username");   
     String user_name=in.nextLine();
     
     int insertLen=user_name.length();
     for(int i=0;i<insertLen;i++){
         
     char ch = user_name.charAt(i);
        
    if(Character.isLowerCase(ch))
         lowercase_Count++;
        
     }
        {
            if(lowercase_Count>=lowercaseLetters) 
                System.out.println("Username succesfully captured");
        
        else{
                System.out.println("The username did not meet the following Criteria:");
                if(lowercase_Count<lowercaseLetters) 
                    System.out.println("not enough characters");
            
            }
        }
          
          
          
        }//end of try scanner
       
    }//end of main method
    private static void printSignupPOEData(SignupPOE signup ) {
        System.out.println(signup.getFirstName());
        System.out.println(signup.getLastName());
        System.out.println(signup.getUserName());
        System.out.println(signup.getPassword());
               
    }
    
    
    
    
}//end of class
