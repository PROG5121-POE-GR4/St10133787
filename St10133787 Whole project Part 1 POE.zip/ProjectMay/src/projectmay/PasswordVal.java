/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectmay;
import java.util.Scanner;
/**
 *
 * @author DISD3
 */
public class PasswordVal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String pass="house";
         
        
         
      System.out.print(checkPasswordValdility(pass));
         
        
        
        
    }//end of main method
    public static boolean checkPasswordValdility(String password)
    {
        if(password.length()>8)
        {
           if(CheckPass(password)) 
           {
               return true;
           }
           else
           {
               return false;
           }
        }
        else
        {
            System.out.print("\nPassword does not meet the criteria\n");
        
            return false;
        }
    }    
          
    
    
    
    public static boolean CheckPass(String Password)
    {
        
        boolean hasNum=false;boolean hasCap=false;boolean hasLow=false;char c;
        for (int i =0;i < Password.length();i++)
        {
            c= Password.charAt(i);
            if(Character.isDigit(c))
            {
                hasNum=true;
            }
            else if(Character.isUpperCase(c)) 
            {
                hasCap=true;
            }
            else if(Character.isLowerCase(c))
            {
                hasLow=true;
                
            }
        if (hasNum && hasCap && hasLow)
        {
            System.out.print("\nPassword is valid\n");
          return true;  
        }
       
        }
        return false;
        }
    
    
        
    
    
}//end of class
